/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg251project;

/**
 *
 * @author 96653
 */
//jamela hadi 
public class Pets {

    private String ill;
    private String bloodtype;

    String type;

    public String getillness() {
        return ill;

    }

    public void setillness(String illness) {
        this.ill = illness;
    }

    public String getbloodtype() {
        return bloodtype;
    }

    public void setbloodgroup(String bloodtype) {
        this.bloodtype = bloodtype;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}